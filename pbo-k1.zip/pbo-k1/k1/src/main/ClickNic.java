package main;

import mainpage.Login;

public class ClickNic {
    
    public static void main(String[] args) {
        Login l = new Login();
    }
}
