-- DATABASE	
   -- CREATE DATABASE
      CREATE DATABASE k1;
      USE k1;

   -- DROP DATABASE
      DROP DATABASE k1

-- TABLE
   -- CREATE TABLE
      CREATE TABLE users(
	`user_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`name` VARCHAR(150) NOT NULL,
	`username` VARCHAR (50) NOT NULL,
	`password` VARCHAR (50) NOT NULL,
	`role` VARCHAR (10) NOT NULL
      );

      CREATE TABLE patient(
	`patient_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`patient_nik` VARCHAR(50) NOT NULL,
	`patient_name` VARCHAR(250) NOT NULL,
	`visit_date` VARCHAR(20) NOT NULL,
	`diagnose` VARCHAR(100) NOT NULL,
	`medicine` VARCHAR(50), 
	`doctor` VARCHAR(150),
	`status` VARCHAR(10)
      );

      CREATE TABLE medicine(
		`med_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
		`med_reg` VARCHAR(20) NOT NULL,
		`med_name` VARCHAR(50) NOT NULL,
		`med_type` VARCHAR(10) NOT NULL,
		`med_date` VARCHAR(10) NOT NULL,
		`pharmacist` VARCHAR(150) NOT NULL
      );

   -- SELECT TABLE
      SELECT * FROM users;
      SELECT * FROM patient;
      SELECT * FROM medicine;

   -- ALTER TABLE
      ALTER TABLE patient MODIFY COLUMN medicine VARCHAR(50);
      ALTER TABLE patient MODIFY COLUMN doctor VARCHAR(150);
      ALTER TABLE patient ADD STATUS VARCHAR(10);

   -- DROP TABLE
      DROP TABLE users;
      DROP TABLE patient;
      DROP TABLE medicine;

-- TABLE VALUES

   -- INSERT INTO TABLE

      INSERT INTO users (NAME, username, PASSWORD, ROLE) VALUES (
	"Admin", "admin", "admin", "Admin");
	
      INSERT INTO users (NAME, username, PASSWORD, ROLE) VALUES (
	"Archico Sembiring", "archico", "archico", "Apoteker");

      INSERT INTO users (NAME, username, PASSWORD, ROLE) VALUES (
	"Rifqi Haikal Chairiansyah", "rifqi", "rifqi", "Pasien");
	
      INSERT INTO users (NAME, username, PASSWORD, ROLE) VALUES (
	"Ella Silaban", "ella", "ella", "Dokter");


      INSERT INTO patient (patient_nik, patient_name, visit_date, diagnose, medicine, doctor, STATUS) VALUES (
	"11S21011", "Archico Sembiring", "28/11/2022", "Demam", "Paracetamol", "dr.Agnes Theresia, S.Ked", "Approved");
	
      INSERT INTO patient (patient_nik, patient_name, visit_date, diagnose, medicine, doctor, STATUS) VALUES (
	"11S21002", "Rifqi Haikal Chairiansyah", "28/11/2022", "Sakit Gigi", "Ambroxol", "dr.Emely Angelica Lestari, S.Ked", "Approved");
		
      INSERT INTO patient (patient_nik, patient_name, visit_date, diagnose, medicine, doctor, STATUS) VALUES (
	"11S21050", "Ella Silaban", "28/11/2022", "Batuk", "Flutamol", "dr.Missyolin Samosir", "Approved");


      INSERT INTO medicine (med_reg, med_name, med_type, med_date, pharmacist) VALUES (
	"REG-12345", "Paracetamol", "Kapsul", "03/12/2022", "apt.Gerald Nathanael, S.Farm");

      INSERT INTO medicine (med_reg, med_name, med_type, med_date, pharmacist) VALUES (
	"REG-13579", "Flutamol", "Sirup", "03/12/2022", "apt.Gerry Bukit, S.Farm");
	
      INSERT INTO medicine (med_reg, med_name, med_type, med_date, pharmacist) VALUES (
	"REG-2468", "Ambroxol", "Tablet", "03/12/2022", "apt.Jayfline Hutagalung, S.Farm");

   -- UPDATE FROM TABLE
      UPDATE users SET NAME="Admin", username="admin" WHERE user_id=1
      UPDATE patient SET NAME="Admin", username="admin" WHERE user_id=2
      UPDATE medicine SET NAME="Admin", username="admin" WHERE user_id=3

   -- DELETE FROM TABLE
      DELETE FROM users WHERE patient_id=1;
      DELETE FROM patient WHERE med_id=2;
      DELETE FROM medicine WHERE med_id=3;
     